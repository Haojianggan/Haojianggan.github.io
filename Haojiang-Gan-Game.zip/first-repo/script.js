//script for title.html
//

//popup open & close
function $(e) {
    return document.getElementById(e);
}

function backstory() {
    $("backstoryPopup").style.visibility = 'visible';
    $("settingsPopup").style.visibility = 'hidden';
    $("skinsPopup").style.visibility = 'hidden'
    $("backgroundsPopup").style.visibility = 'hidden'
}
function backstoryClose() {
    $("backstoryPopup").style.visibility = 'hidden';

}
function settings() {
    $("settingsPopup").style.visibility = 'visible';
    $("skinsPopup").style.visibility = 'hidden'
    $("backgroundsPopup").style.visibility = 'hidden'
    $("backstoryPopup").style.visibility = 'hidden';

}

function settingsClose() {
    $("settingsPopup").style.visibility = 'hidden';

}

function skins() {
    $("skinsPopup").style.visibility = 'visible'
    if ($("settingsPopup").style.visibility === 'visible') {
        $("settingsPopup").style.visibility = 'hidden'
    }
}

function skinsClose() {
    $("skinsPopup").style.visibility = 'hidden';
}

//script for index.html
//
let w = window.innerWidth;
let h = window.innerHeight;
//global variable for collision detection
let eat = false;
//store enemy x and y
let eX = w/2
let eY = h/2
let eW = 100
let eH = 100

//score
let score = 0
let anotherScore;
//paused
let paused = false

//skins
function defaultSkinSelect() {
    localStorage.setItem("localStorageSkin", 0);
    $("defaultSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function eyeSkinSelect() {
    localStorage.setItem("localStorageSkin", 1);
    $("eyeSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("defaultSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";

}
function hollowSkinSelect() {
    localStorage.setItem("localStorageSkin", 2);
    $("hollowSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("defaultSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";

}
function robotSkinSelect() {
    localStorage.setItem("localStorageSkin", 3);
    $("robotSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("defaultSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";

}
function bubbleSkinSelect() {
    localStorage.setItem("localStorageSkin", 4);
    $("bubbleSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("defaultSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";

}
function pumpkinSkinSelect() {
    localStorage.setItem("localStorageSkin", 5);
    $("pumpkinSkinButton").style.borderWidth = "10px";
    $("defaultSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}

//background popup functions
function backgroundsPopup() {
    $("backgroundsPopup").style.visibility = 'visible'
    $("skinsPopup").style.visibility = 'hidden'
    $("settingsPopup").style.visibility = 'hidden'
}
function skinsPopup() {
    $("skinsPopup").style.visibility = 'visible'
    $("backgroundsPopup").style.visibility = 'hidden'
    $("settingsPopup").style.visibility = 'hidden'
}
function backgroundsClose() {
    $("backgroundsPopup").style.visibility = 'hidden'
}
function underwaterBgSelect() {
    document.body.style.background = 'url(underwaterBg.png)'
    localStorage.setItem("localStorageBg", 0)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "10px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function spaceBgSelect() {
    document.body.style.background = 'url(spaceBg.png)'
    localStorage.setItem("localStorageBg", 1)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "1px";
    $("pumpkinSkinButton").style.borderWidth = "10px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function skyBgSelect() {
    document.body.style.background = 'url(skyBg.png)'
    localStorage.setItem("localStorageBg", 2)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "1px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "10px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function scifiBgSelect() {
    document.body.style.background = 'url(scifiBg.png)'
    localStorage.setItem("localStorageBg", 3)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "1px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "10px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function scaryBgSelect() {
    document.body.style.background = 'url(scaryBg.png)'
    localStorage.setItem("localStorageBg", 4)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "1px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "10px";
    $("bubbleSkinButton").style.borderWidth = "1px";
}
function forestBgSelect() {
    document.body.style.background = 'url(forestBg.png)'
    localStorage.setItem("localStorageBg", 5)
    location.reload()
    $("defaultSkinButton").style.borderWidth = "1px";
    $("pumpkinSkinButton").style.borderWidth = "1px";
    $("eyeSkinButton").style.borderWidth = "1px";
    $("hollowSkinButton").style.borderWidth = "1px";
    $("robotSkinButton").style.borderWidth = "1px";
    $("bubbleSkinButton").style.borderWidth = "10px";
}
console.log(localStorage.getItem("localStorageBackground"))
//get high score
function highScore() {
    anotherScore = score
    if (anotherScore > localStorage.getItem("higherScore")) {
        localStorage.setItem("higherScore", anotherScore)
        anotherScore = 0
    }
    location.href = "index.html"
}
function restart() {
    location.reload()
}
function keyPressed() {
    if (keyIsDown(27) && paused === false) {
        noLoop()
        paused = true
        $("paused").style.display = "flex"
        $("gameBody").style.cursor = "auto";
        $("displayScore").style.cursor = "auto";

    }
    else if (keyIsDown(27) && paused === true){
        loop()
        paused = false
        $("paused").style.display = "none"
        $("gameBody").style.cursor = "none";
        $("displayScore").style.cursor = "none";
    }
}

//difficulty script
function enemy1() {
    localStorage.setItem("enemyAm", 3);
    location.href= "game.html"
}
function enemy2() {
    localStorage.setItem("enemyAm", 6);
    location.href = "game.html"
}
function enemy3() {
    let enemyInputAm = document.getElementById("enemyInput").value
    if (enemyInputAm >= 1 && enemyInputAm <= 50 || !enemyInputAm === null) {
        localStorage.setItem("enemyAm", enemyInputAm)
        location.href = "game.html"
    }
    else {
        window.alert("1-50 only PLEASE!!!!!")
    }
    console.log(localStorage.getItem("enemyAm"))
}